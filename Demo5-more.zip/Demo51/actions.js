//Tao dau tien
export const tang=()=>({type: 'TANG'});//khai bao ham tang
export const giam=()=>({type: 'GIAM'});//khai bao ham giam