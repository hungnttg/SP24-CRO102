import React, { useRef } from 'react';
import { View, Text, TouchableOpacity } from 'react-native';
import ViewShot from 'react-native-view-shot';

const CaptureApp = () => {
  const viewRef = useRef();

  const captureScreen = async () => {
    try {
      const uri = await viewRef.current.capture();
      console.log('Chup anh thanh cong:', uri);
    } catch (error) {
      console.error('Loi chup anh:', error);
    }
  };

  return (
    <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
      <ViewShot ref={viewRef} options={{ format: 'jpg', quality: 0.9 }}>
        <Text>Screen Content to Capture</Text>
      </ViewShot>
      <TouchableOpacity onPress={captureScreen}>
        <Text style={{ marginTop: 20, color: 'blue' }}>Capture Screen</Text>
      </TouchableOpacity>
    </View>
  );
};

export default CaptureApp;
