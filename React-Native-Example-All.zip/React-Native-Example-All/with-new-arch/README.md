# [New Architecture Example](https://reactnative.dev/docs/the-new-architecture/landing-page)

## 🚀 How to use

> `npx create-expo-app@latest -e with-new-arch`

- Install packages with `yarn` or `npm install`.
- Run `npx expo run:ios` and/or `npx expo run:android`. Requires native toolchains to be installed.