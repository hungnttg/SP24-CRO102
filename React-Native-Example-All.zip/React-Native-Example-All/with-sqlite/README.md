# SQLite Example

<p>
  <!-- iOS -->
  <img alt="Supports Expo iOS" longdesc="Supports Expo iOS" src="https://img.shields.io/badge/iOS-4630EB.svg?style=flat-square&logo=APPLE&labelColor=999999&logoColor=fff" />
  <!-- Android -->
  <img alt="Supports Expo Android" longdesc="Supports Expo Android" src="https://img.shields.io/badge/Android-4630EB.svg?style=flat-square&logo=ANDROID&labelColor=A4C639&logoColor=fff" />
</p>

Example demonstrating use of the `SQLite` API in Expo.

The app allows adding todo items, marking them as done, and deleting done items.
`SQLite` features used include creating and opening databases, creating tables,
inserting items, querying and displaying results, using prepared statements.

![Simulator Example](https://i.imgur.com/CDrXKzV.png)

## 🚀 How to use

- Run `yarn` or `npm install`
- Run `yarn start` or `npm run start` to try it out.

## 📝 Notes

- [Expo SQLite docs](https://docs.expo.dev/versions/latest/sdk/sqlite/)
