# Video Background Example

Video backgrounds are common in mobile apps. This shows you how to do it universally with Expo.

## How to use

- Install: `yarn`

- Run Project Locally: `yarn start` or `npm run start`

