export default ({ config }) => ({
  ...config,
  splash: {
    image:
      "https://github.com/expo/expo/blob/master/templates/expo-template-blank/assets/splash.png?raw=true",
  },
});
