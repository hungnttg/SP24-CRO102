import * as React from 'react';
// @ts-ignore
import { Text } from 'react-native';

export function MyView() {
  return <Text>Hello from the first package</Text>;
}
