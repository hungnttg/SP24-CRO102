// No-op on native. For offline support in native apps, check out expo-updates.

export function register(config) {}

export function unregister() {}
