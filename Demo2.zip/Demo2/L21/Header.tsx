import React from "react";
import { Text,View } from "react-native";
const Header=()=>{
    return(
        <View>
            <Text>Header Component</Text>
        </View>
    );
}
export default Header;