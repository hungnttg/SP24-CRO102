import React,{useState} from "react";
import { Text,View,Button } from "react-native";
const Body=({ onSubmit }:{onSubmit: (inputValue: string)=> void })=>{
    const [inputValue, setInputValue]=useState('');
    const handleSubmit=(e: React.FormEvent)=>{
        e.preventDefault();
        onSubmit(inputValue);
        setInputValue('');      
    };
    return(
        <main>
            <form onSubmit={handleSubmit}>
                <label>
                    Input:
                    <input type="text" value={inputValue}
                    onChange={(e)=> setInputValue(e.target.value)} />
                </label>
                <button type="submit">Submit</button>
            </form>
        </main>
    );
};
export default Body;