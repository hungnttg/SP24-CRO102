import React,{useState} from "react";
import Header from "./Header";
import Footer from "./Footer";
import Body from "./Body";
const Main1=()=>{
    const [footerInfo,setFooterInfo]=useState('');
    const handleSubmit=(inputValue: string)=>{
        setFooterInfo(inputValue);
    };
    return(
        <div>
            <Header/>
            <Body onSubmit={handleSubmit}/>
            <Footer info={footerInfo}/>
        </div>
    );
}
export default Main1;