import React,{useEffect,useState} from "react";
import { Text,View,Button } from "react-native";
const LT23 = () =>{
    const [count, setCount]=useState(0);
    useEffect(()=>{
        //ham duoc goi sau moi lan render
        console.log("co thay doi gia tri");
    });
    return(
        <View>
            <Text>Count: {count}</Text>
            <Button title="Tang" onPress={()=> setCount(count+1)} />
        </View>
    );
}
export default LT23;