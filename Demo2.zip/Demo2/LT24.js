import React,{useCallback,useState} from "react";
import { Button,Text,View } from "react-native";
//dinh nghia thanh phan con
const ChildComponent=({onClick})=>{
    return <button onClick={onClick}>Click me</button>
}
//dinh nghia thanh phan cha
const ParentComponent=()=>{
    const [count, setCount] = useState(0);
    const handleClick=useCallback(()=>{
        setCount(count+1);
    },[count]);
    return(
        <View>
            <Text>CountL {count}</Text>
            <ChildComponent onClick={handleClick} />
        </View>
    );
}
export default ParentComponent;